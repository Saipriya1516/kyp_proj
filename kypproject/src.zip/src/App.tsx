 
//import axios from 'axios'
import './App.css'
import Displayall from './components/Displayall'
import NavBar from './components/NavBar';
//import FilterComponent from './components/FilterComponent';

function App() {
  return (<div>
   
    <NavBar/>
    <Displayall/>
    
  </div>
  );
}

export default App
